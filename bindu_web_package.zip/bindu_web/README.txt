Bindu Web Deployment

Files:
- app.py                 -> FastAPI backend for the Bindu runtime
- frontend.html          -> Web UI with button label "WL = FIX IT"
- squarespace_embed.html -> Embed snippet for Squarespace
- bindu_web_runtime.db   -> Created at runtime by the API

Run locally:
1. Make sure /mnt/data/bindu_runtime exists alongside this folder.
2. Install dependencies:
   pip install fastapi uvicorn
3. Start backend:
   uvicorn app:app --host 127.0.0.1 --port 8000 --reload
4. Open frontend.html in a browser.
5. Leave API URL as http://127.0.0.1:8000/solve

Squarespace path:
- Host frontend.html somewhere public
- Host the FastAPI backend somewhere public
- Put the iframe snippet from squarespace_embed.html into a Squarespace Embed Block
- Update the API URL in the frontend to your public backend URL
