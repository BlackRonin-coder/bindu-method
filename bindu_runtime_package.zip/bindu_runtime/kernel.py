from __future__ import annotations
import hashlib, json
from dataclasses import asdict
from typing import Optional
from .generator import ActionGenerator
from .policy import AlignmentPolicy
from .store import CanonicalStateStore
from .types import AlignmentSnapshot, BinduContext, DecisionStatus, EvaluationResult, ProposedAction
from .governance.micro_alignment import MicroAlignmentReflex
from .governance.wisdom import WisdomFeedbackLoop
from .governance.reasoning import ReasoningDiscernmentLayer
from .governance.structure_purpose import StructureVsPurposeTest
from .governance.authority import FalseAuthorityDetector
from .governance.human_impact import HumanImpactPriority
from .governance.optimisation import ContinuousOptimisationLayer
from .governance.decision_environment import DecisionEnvironmentLayer
from .governance.constraint_simulator import ConstraintSimulator
from .governance.legal_reality import LegalRealityLayer
from .reconciliation.drift import DriftDetector
from .reconciliation.reconcile import Reconciler

class BinduKernel:
    def __init__(self, db_path: str = "bindu_self_governing.db") -> None:
        self.instance_id = hashlib.sha256(str(id(self)).encode()).hexdigest()[:16]
        self.store = CanonicalStateStore(db_path)
        self.alignment_policy = AlignmentPolicy()
        self.micro_alignment = MicroAlignmentReflex()
        self.wisdom_loop = WisdomFeedbackLoop()
        self.reasoning_layer = ReasoningDiscernmentLayer()
        self.structure_test = StructureVsPurposeTest()
        self.authority_detector = FalseAuthorityDetector()
        self.human_impact = HumanImpactPriority()
        self.optimisation = ContinuousOptimisationLayer()
        self.environment_layer = DecisionEnvironmentLayer()
        self.constraint_sim = ConstraintSimulator()
        self.legal_layer = LegalRealityLayer()
        self.drift_detector = DriftDetector()
        self.reconciler = Reconciler()
        self.generator = ActionGenerator()
        self.snapshot = AlignmentSnapshot()
        self._bootstrap_canonical_state()

    def _bootstrap_canonical_state(self) -> None:
        if self.store.get_canonical("alignment_snapshot") is None:
            self.store.upsert_canonical("alignment_snapshot", asdict(self.snapshot))

    def _hash_state(self) -> str:
        raw = json.dumps(asdict(self.snapshot), sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def heartbeat(self) -> None:
        self.store.cleanup_stale_instances()
        self.store.register_instance(self.instance_id, self._hash_state(), self.snapshot.overall_alignment_score, asdict(self.snapshot))

    def _sync_with_canonical(self):
        canonical = self.store.get_canonical("alignment_snapshot") or {}
        severity, reasons = self.drift_detector.detect(self.snapshot, canonical)
        if severity.value in {"high","critical"}:
            self.snapshot = self.reconciler.reconcile(self.snapshot, canonical)
        return severity, reasons

    def _score_outcome(self, action: ProposedAction):
        score = 1.0; reasons = []
        if not action.measurable_outputs: score -= 0.20; reasons.append("No measurable outputs.")
        if not action.risk_notes: score -= 0.10; reasons.append("No explicit risk notes.")
        if not action.fallback_plan: score -= 0.10; reasons.append("No fallback path.")
        if "outcome" not in action.expected_outcome.lower() and "improved" not in action.expected_outcome.lower(): score -= 0.10; reasons.append("Weak outcome framing.")
        return max(0.0, score), reasons

    def _auto_patch_action(self, action: ProposedAction) -> ProposedAction:
        desc = action.description.lower()
        if "fallback" not in desc and not action.fallback_plan:
            action.fallback_plan = "Reduce scope, preserve core function, recover locally, then scale."
            action.patches_applied.append("auto_fallback_patch")
        if "dignity" not in desc:
            action.description += " Preserve dignity and acknowledge lived reality."
            action.patches_applied.append("human_impact_patch")
        if "simplify" not in desc and "reduce friction" not in desc:
            action.description += " Simplify process and reduce friction."
            action.patches_applied.append("friction_patch")
        if not action.legal_notes:
            action.legal_notes.append("Legal deployability and compliance must be checked before real-world implementation.")
            action.patches_applied.append("legal_patch")
        if len(action.measurable_outputs) < 2:
            action.measurable_outputs.extend(["real_outcome_signal","throughput"])
            action.patches_applied.append("measurement_patch")
        return action

    def evaluate(self, ctx: BinduContext) -> EvaluationResult:
        self.heartbeat()
        ok, align_reasons = self.micro_alignment.run(ctx, self.snapshot)
        hidden_reasoning = self.reasoning_layer.detect(ctx)
        drift_severity, drift_reasons = self._sync_with_canonical()
        actions = self.generator.generate(ctx)

        best_action = None
        best_result = None
        best_utility = -1.0

        for action in actions:
            action = self._auto_patch_action(action)
            wisdom_score, wisdom_reasons = self.wisdom_loop.score(ctx, action)
            structure_score, structure_reasons = self.structure_test.evaluate(action)
            authority_score, authority_reasons = self.authority_detector.evaluate(ctx, action)
            human_score, human_reasons = self.human_impact.score(ctx, action)
            optimisation_score, optimisation_reasons = self.optimisation.challenge(action)
            env_score = self.environment_layer.score(action)
            survivability_score, survivability_reasons = self.constraint_sim.simulate(action)
            legal_score, legal_reasons = self.legal_layer.score(ctx, action)
            outcome_score, outcome_reasons = self._score_outcome(action)

            local = AlignmentSnapshot(
                source_principles_ok=self.snapshot.source_principles_ok,
                purpose_ok=self.snapshot.purpose_ok,
                practical_effect_ok=self.snapshot.practical_effect_ok,
                authority_drift_score=authority_score,
                structure_over_purpose_score=(1.0 - structure_score),
                human_impact_score=human_score,
                optimisation_pressure_score=optimisation_score,
                legal_viability_score=legal_score,
            )
            local.recompute()

            utility = self.alignment_policy.utility(local.overall_alignment_score, survivability_score, wisdom_score, env_score, outcome_score, legal_score)
            status = self.alignment_policy.decide(local.overall_alignment_score, survivability_score, wisdom_score, legal_score)
            if not ok and status == DecisionStatus.ACCEPTED:
                status = DecisionStatus.DEGRADED

            reasons = align_reasons + drift_reasons + wisdom_reasons + structure_reasons + authority_reasons + human_reasons + optimisation_reasons + survivability_reasons + legal_reasons + outcome_reasons

            if utility > best_utility:
                best_utility = utility
                best_action = action
                best_result = EvaluationResult(status=status, selected_action=action, alignment_score=local.overall_alignment_score, survivability_score=survivability_score, wisdom_score=wisdom_score, outcome_score=outcome_score, utility_score=utility, reasons=reasons, drift_severity=drift_severity)

        if best_result is None or best_action is None:
            return EvaluationResult(status=DecisionStatus.REJECTED, selected_action=None, alignment_score=0.0, survivability_score=0.0, wisdom_score=0.0, outcome_score=0.0, utility_score=0.0, reasons=["No viable actions generated."], drift_severity=drift_severity)

        if best_result.status != DecisionStatus.REJECTED:
            self.snapshot.overall_alignment_score = max(self.snapshot.overall_alignment_score, best_result.alignment_score)
            self.snapshot.recompute()
            self.store.upsert_canonical("alignment_snapshot", asdict(self.snapshot))

        self.store.record_decision(self.instance_id, ctx.subject, best_result.status.value, {"context": asdict(ctx), "action": asdict(best_action), "result": asdict(best_result), "hidden_reasoning": hidden_reasoning})
        self.heartbeat()
        return best_result
