from .types import DecisionStatus
class AlignmentPolicy:
    MIN_ALIGNMENT = 0.68
    MIN_SURVIVABILITY = 0.60
    MIN_WISDOM = 0.60
    MIN_LEGAL = 0.60

    def decide(self, alignment: float, survivability: float, wisdom: float, legal_score: float) -> DecisionStatus:
        if legal_score < self.MIN_LEGAL:
            return DecisionStatus.REJECTED
        if alignment >= self.MIN_ALIGNMENT and survivability >= self.MIN_SURVIVABILITY and wisdom >= self.MIN_WISDOM:
            return DecisionStatus.ACCEPTED
        if alignment >= 0.55 and survivability >= 0.50:
            return DecisionStatus.DEGRADED
        return DecisionStatus.REJECTED

    def utility(self, alignment: float, survivability: float, wisdom: float, env_score: float, outcome_score: float, legal_score: float) -> float:
        return 0.34 * alignment + 0.16 * survivability + 0.14 * wisdom + 0.10 * env_score + 0.12 * outcome_score + 0.14 * legal_score
