from .adapters.home_adapter import HOMEAdapter
from .types import BinduContext, ProposedAction
class ActionGenerator:
    def __init__(self) -> None:
        self.home_adapter = HOMEAdapter()
    def generate(self, ctx: BinduContext):
        subject = ctx.subject.lower()
        actions = []
        if "home" in subject or "housing" in subject:
            actions.extend(self.home_adapter.generate_actions(ctx))
        base = ProposedAction(
            name="structural_alignment_action",
            description="Reduce friction, simplify the operating pathway, preserve dignity, acknowledge lived reality, include fallback, iterate continuously, and tie incentives to measurable outcome and legally compliant delivery.",
            expected_outcome="Improved outcome through lower friction and stronger alignment.",
            measurable_outputs=["throughput","wait_time","real_outcome_improvement"],
            assumptions=list(ctx.assumptions),
            risk_notes=["partial resistance","implementation lag"],
            incentives={"clarity":0.95,"consequence_visibility":0.90,"low_friction_for_correct_action":0.88,"penalise_wrong_action":0.72},
            fallback_plan="Reduce scope, preserve core function locally, then scale outward.",
            legal_notes=["Legally deployable and compliance-aware by design."],
            patches_applied=["WL","micro_alignment","continuous_optimisation","legal_reality"],
        )
        bad_option = ProposedAction(
            name="process_heavy_control_model",
            description="Expand reporting workflow, centralise approvals, increase procedure count, single channel control, no meaningful simplification.",
            expected_outcome="Nominal target compliance.",
            measurable_outputs=["report_submission_rate"],
            assumptions=["ideal behaviour","zero delay"],
            risk_notes=["bureaucratic accumulation","false progress"],
            incentives={"clarity":0.40,"consequence_visibility":0.30,"low_friction_for_correct_action":0.20,"penalise_wrong_action":0.70},
        )
        actions.append(base)
        actions.append(bad_option)
        return actions
