from typing import Dict
from ..types import AlignmentSnapshot
class Reconciler:
    def reconcile(self, local_snapshot: AlignmentSnapshot, canonical_snapshot: Dict[str, float]) -> AlignmentSnapshot:
        local_snapshot.source_principles_ok = canonical_snapshot.get("source_principles_ok", True)
        local_snapshot.purpose_ok = canonical_snapshot.get("purpose_ok", True)
        local_snapshot.practical_effect_ok = canonical_snapshot.get("practical_effect_ok", True)
        local_snapshot.authority_drift_score = min(local_snapshot.authority_drift_score, float(canonical_snapshot.get("authority_drift_score", 0.0)))
        local_snapshot.structure_over_purpose_score = min(local_snapshot.structure_over_purpose_score, float(canonical_snapshot.get("structure_over_purpose_score", 0.0)))
        local_snapshot.human_impact_score = max(local_snapshot.human_impact_score, float(canonical_snapshot.get("human_impact_score", 1.0)))
        local_snapshot.optimisation_pressure_score = max(local_snapshot.optimisation_pressure_score, float(canonical_snapshot.get("optimisation_pressure_score", 1.0)))
        local_snapshot.legal_viability_score = max(local_snapshot.legal_viability_score, float(canonical_snapshot.get("legal_viability_score", 1.0)))
        local_snapshot.recompute()
        return local_snapshot
