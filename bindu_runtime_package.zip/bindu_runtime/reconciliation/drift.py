from typing import Dict, List, Tuple
from ..types import AlignmentSnapshot, DriftSeverity
class DriftDetector:
    def detect(self, local_snapshot: AlignmentSnapshot, canonical_snapshot: Dict[str, float]) -> Tuple[DriftSeverity, List[str]]:
        reasons = []
        canonical_score = float(canonical_snapshot.get("overall_alignment_score", 1.0))
        delta = abs(local_snapshot.overall_alignment_score - canonical_score)
        if delta < 0.05: return DriftSeverity.NONE, reasons
        if delta < 0.15: reasons.append("Low alignment drift."); return DriftSeverity.LOW, reasons
        if delta < 0.30: reasons.append("Medium alignment drift."); return DriftSeverity.MEDIUM, reasons
        if delta < 0.45: reasons.append("High alignment drift."); return DriftSeverity.HIGH, reasons
        reasons.append("Critical alignment drift."); return DriftSeverity.CRITICAL, reasons
