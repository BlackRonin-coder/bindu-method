from typing import List, Tuple
from ..types import BinduContext, ProposedAction
class LegalRealityLayer:
    def score(self, ctx: BinduContext, action: ProposedAction) -> Tuple[float, List[str]]:
        if not ctx.legal_constraints: return 1.0, []
        score = 1.0; reasons = []; text = f"{action.description} {' '.join(action.legal_notes)}".lower()
        for constraint in ctx.legal_constraints:
            if "legally deployable" in constraint.lower():
                if "legal" not in text and "compliant" not in text:
                    score -= 0.20; reasons.append("Legal deployability not addressed.")
        return max(0.0, score), reasons
