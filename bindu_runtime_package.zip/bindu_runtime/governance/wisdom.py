from typing import List, Tuple
from ..types import BinduContext, ProposedAction
class WisdomFeedbackLoop:
    def score(self, ctx: BinduContext, action: ProposedAction) -> Tuple[float, List[str]]:
        score = 1.0; reasons = []
        if not action.expected_outcome: score -= 0.20; reasons.append("Missing expected outcome.")
        if not action.measurable_outputs: score -= 0.20; reasons.append("Missing measurable outputs.")
        if len(action.assumptions) > 4: score -= 0.10; reasons.append("Too many assumptions.")
        if ctx.human_impact and "dignity" not in action.description.lower(): score -= 0.05; reasons.append("Dignity not explicit.")
        if not action.fallback_plan: score -= 0.10; reasons.append("No fallback plan.")
        return max(0.0, score), reasons
