from typing import List, Tuple
from ..types import ProposedAction
class ConstraintSimulator:
    def simulate(self, action: ProposedAction) -> Tuple[float, List[str]]:
        score = 1.0; reasons = []
        if len(action.assumptions) > 3: score -= 0.15; reasons.append("Too many assumptions.")
        if "single channel" in action.description.lower(): score -= 0.25; reasons.append("Single-channel fragility.")
        if "ideal behaviour" in action.description.lower(): score -= 0.30; reasons.append("Depends on ideal behaviour.")
        if not action.fallback_plan: score -= 0.10; reasons.append("No fallback path.")
        return max(0.0, score), reasons
