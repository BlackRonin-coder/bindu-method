from ..types import ProposedAction
class DecisionEnvironmentLayer:
    def score(self, action: ProposedAction) -> float:
        i = action.incentives or {}
        return 0.30 * i.get("clarity", 0.0) + 0.30 * i.get("consequence_visibility", 0.0) + 0.25 * i.get("low_friction_for_correct_action", 0.0) + 0.15 * i.get("penalise_wrong_action", 0.0)
