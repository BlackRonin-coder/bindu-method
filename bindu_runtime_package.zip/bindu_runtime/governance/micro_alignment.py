from typing import List, Tuple
from ..types import AlignmentSnapshot, BinduContext
class MicroAlignmentReflex:
    def run(self, ctx: BinduContext, snapshot: AlignmentSnapshot) -> Tuple[bool, List[str]]:
        reasons = []
        source_ok = bool(ctx.purpose.strip())
        purpose_ok = bool(ctx.purpose.strip())
        practical_ok = bool(ctx.human_impact) or bool(ctx.environment_signals) or bool(ctx.constraints)
        snapshot.source_principles_ok = source_ok
        snapshot.purpose_ok = purpose_ok
        snapshot.practical_effect_ok = practical_ok
        snapshot.recompute()
        if not source_ok: reasons.append("Missing governing purpose/source anchor.")
        if not purpose_ok: reasons.append("Request not clearly anchored to purpose.")
        if not practical_ok: reasons.append("Practical effect insufficiently grounded.")
        return snapshot.overall_alignment_score >= 0.65, reasons
