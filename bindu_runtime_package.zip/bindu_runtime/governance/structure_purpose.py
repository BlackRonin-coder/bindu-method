from typing import List, Tuple
from ..types import ProposedAction
class StructureVsPurposeTest:
    def evaluate(self, action: ProposedAction) -> Tuple[float, List[str]]:
        score = 1.0; reasons = []
        process_words = ["process","procedure","workflow","compliance","reporting"]
        outcome_words = ["outcome","impact","delivery","result","throughput"]
        process_hits = sum(w in action.description.lower() for w in process_words)
        outcome_hits = sum(w in action.description.lower() for w in outcome_words)
        if process_hits > outcome_hits: score -= 0.30; reasons.append("Structure appears to dominate purpose.")
        if not action.measurable_outputs: score -= 0.15; reasons.append("Weak outcome measurement.")
        return max(0.0, score), reasons
