from typing import List, Tuple
from ..types import BinduContext, ProposedAction
class HumanImpactPriority:
    def score(self, ctx: BinduContext, action: ProposedAction) -> Tuple[float, List[str]]:
        if not ctx.human_impact: return 1.0, []
        score = 1.0; reasons = []; text = action.description.lower()
        if "dignity" not in text: score -= 0.10; reasons.append("Dignity not explicitly preserved.")
        if "lived reality" not in text and "real-world" not in text: score -= 0.10; reasons.append("Lived reality not explicitly acknowledged.")
        return max(0.0, score), reasons
