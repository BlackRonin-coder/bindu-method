from typing import List, Tuple
from ..types import ProposedAction
class ContinuousOptimisationLayer:
    def challenge(self, action: ProposedAction) -> Tuple[float, List[str]]:
        score = 1.0; reasons = []
        if len(action.measurable_outputs) < 2: score -= 0.10; reasons.append("Too few measurable outputs.")
        if "simplify" not in action.description.lower() and "reduce friction" not in action.description.lower(): score -= 0.10; reasons.append("No explicit friction reduction.")
        if "continuous" not in action.description.lower() and "iterate" not in action.description.lower(): score -= 0.05; reasons.append("Weak optimisation signal.")
        return max(0.0, score), reasons
