from typing import Any, Dict
from ..types import BinduContext
class ReasoningDiscernmentLayer:
    def detect(self, ctx: BinduContext) -> Dict[str, Any]:
        text = ctx.request.lower()
        return {"seeking_understanding": any(x in text for x in ["how","why","explain"]),
                "seeking_advantage": any(x in text for x in ["maximize","gain","capture"]),
                "surface_problem": ctx.subject,
                "hidden_assumptions": ctx.assumptions}
