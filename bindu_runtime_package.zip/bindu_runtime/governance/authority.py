from typing import List, Tuple
from ..types import BinduContext, ProposedAction
class FalseAuthorityDetector:
    def evaluate(self, ctx: BinduContext, action: ProposedAction) -> Tuple[float, List[str]]:
        score = 0.0; reasons = []
        risky = ["must obey","cannot question","approved conclusions only","leadership decides all"]
        text = f"{ctx.request} {action.description}".lower()
        for marker in risky:
            if marker in text: score += 0.25; reasons.append(f"Authority drift marker detected: {marker}")
        return min(1.0, score), reasons
