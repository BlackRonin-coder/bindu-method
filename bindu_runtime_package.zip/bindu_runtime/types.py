from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

class DecisionStatus(str, Enum):
    ACCEPTED = "accepted"
    DEGRADED = "degraded"
    REJECTED = "rejected"

class DriftSeverity(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class BinduContext:
    subject: str
    request: str
    purpose: str
    constraints: List[str] = field(default_factory=list)
    legal_constraints: List[str] = field(default_factory=list)
    human_impact: Optional[str] = None
    environment_signals: Dict[str, Any] = field(default_factory=dict)
    assumptions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class AlignmentSnapshot:
    source_principles_ok: bool = True
    purpose_ok: bool = True
    practical_effect_ok: bool = True
    authority_drift_score: float = 0.0
    structure_over_purpose_score: float = 0.0
    human_impact_score: float = 1.0
    optimisation_pressure_score: float = 1.0
    legal_viability_score: float = 1.0
    overall_alignment_score: float = 1.0

    def recompute(self) -> None:
        penalty = (
            self.authority_drift_score * 0.18
            + self.structure_over_purpose_score * 0.18
            + (1.0 - self.human_impact_score) * 0.14
            + (1.0 - self.optimisation_pressure_score) * 0.10
            + (1.0 - self.legal_viability_score) * 0.20
        )
        base = 1.0
        if not self.source_principles_ok:
            base -= 0.08
        if not self.purpose_ok:
            base -= 0.12
        if not self.practical_effect_ok:
            base -= 0.12
        self.overall_alignment_score = max(0.0, min(1.0, base - penalty))

@dataclass
class ProposedAction:
    name: str
    description: str
    expected_outcome: str
    measurable_outputs: List[str] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)
    risk_notes: List[str] = field(default_factory=list)
    incentives: Dict[str, float] = field(default_factory=dict)
    fallback_plan: str = ""
    legal_notes: List[str] = field(default_factory=list)
    patches_applied: List[str] = field(default_factory=list)

@dataclass
class EvaluationResult:
    status: DecisionStatus
    selected_action: Optional[ProposedAction]
    alignment_score: float
    survivability_score: float
    wisdom_score: float
    outcome_score: float
    utility_score: float
    reasons: List[str] = field(default_factory=list)
    drift_severity: DriftSeverity = DriftSeverity.NONE
