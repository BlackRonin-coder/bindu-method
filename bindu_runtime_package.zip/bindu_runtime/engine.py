from .kernel import BinduKernel
from .store import CanonicalStateStore
from .types import BinduContext, EvaluationResult

class WLEngine:
    def __init__(self, db_path: str = "bindu_self_governing.db") -> None:
        self.store = CanonicalStateStore(db_path)
        self.kernel = BinduKernel(db_path)

    def submit_context(self, ctx: BinduContext) -> str:
        return self.store.add_task({"context": ctx.__dict__})

    def run_once(self) -> EvaluationResult | None:
        claimed = self.store.claim_task()
        if not claimed: return None
        task_id, payload = claimed
        ctx = BinduContext(**payload["context"])
        result = self.kernel.evaluate(ctx)
        self.store.complete_task(task_id, result.status.value)
        return result
