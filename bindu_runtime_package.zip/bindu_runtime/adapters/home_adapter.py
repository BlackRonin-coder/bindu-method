from ..types import BinduContext, ProposedAction
class HOMEAdapter:
    def generate_actions(self, ctx: BinduContext):
        return [
            ProposedAction(
                name="home_multi_channel_supply_fix",
                description="Reduce planning friction, simplify housing delivery pathways, preserve dignity, acknowledge lived reality, increase multi-channel supply, reduce friction, and iterate continuously with legally compliant delivery.",
                expected_outcome="Improved housing delivery outcome under planning and capital constraints.",
                measurable_outputs=["approvals_to_completion_time","housing_supply_gain","lived_outcome_signal"],
                assumptions=list(ctx.assumptions[:2]),
                risk_notes=["developer resistance","planning inertia"],
                incentives={"clarity":0.94,"consequence_visibility":0.86,"low_friction_for_correct_action":0.84,"penalise_wrong_action":0.74},
                fallback_plan="Reduce to local delivery zone, prove throughput, then scale.",
                legal_notes=["Housing reform must remain legally deployable and planning-law aware."],
                patches_applied=["HOME_adapter","WL"],
            ),
            ProposedAction(
                name="home_sme_modular_pathway",
                description="Simplify approvals for SME builders, reduce friction for modular and offsite delivery, preserve dignity, acknowledge lived reality, and keep the system anchored to outcome rather than process.",
                expected_outcome="Improved housing delivery outcome through diversified supply channels.",
                measurable_outputs=["sme_builder_share","modular_output_share","delivery_rate"],
                assumptions=list(ctx.assumptions[:2]),
                risk_notes=["scaling lag"],
                incentives={"clarity":0.90,"consequence_visibility":0.82,"low_friction_for_correct_action":0.88,"penalise_wrong_action":0.68},
                fallback_plan="Concentrate on strategic sites first, then widen the route.",
                legal_notes=["Must remain legally deployable and compliant with planning standards."],
                patches_applied=["HOME_adapter","channel_diversification"],
            ),
        ]
