from __future__ import annotations
import json, sqlite3, time, uuid
from typing import Any, Dict, Optional, Tuple

class CanonicalStateStore:
    def __init__(self, db_path: str = "bindu_self_governing.db") -> None:
        self.db_path = db_path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS canonical_state (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS instances (instance_id TEXT PRIMARY KEY, heartbeat REAL NOT NULL, state_hash TEXT NOT NULL, alignment_score REAL NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS decisions (decision_id TEXT PRIMARY KEY, instance_id TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL, created_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS tasks (task_id TEXT PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL);
            """)
            conn.commit()

    def upsert_canonical(self, key: str, value: Dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO canonical_state (key, value, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
            """, (key, json.dumps(value, sort_keys=True), time.time()))
            conn.commit()

    def get_canonical(self, key: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM canonical_state WHERE key = ?", (key,)).fetchone()
            return json.loads(row["value"]) if row else None

    def register_instance(self, instance_id: str, state_hash: str, alignment_score: float, payload: Dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO instances (instance_id, heartbeat, state_hash, alignment_score, payload)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(instance_id) DO UPDATE SET heartbeat=excluded.heartbeat, state_hash=excluded.state_hash, alignment_score=excluded.alignment_score, payload=excluded.payload
            """, (instance_id, time.time(), state_hash, alignment_score, json.dumps(payload, sort_keys=True)))
            conn.commit()

    def cleanup_stale_instances(self, max_age_seconds: int = 300) -> None:
        cutoff = time.time() - max_age_seconds
        with self._connect() as conn:
            conn.execute("DELETE FROM instances WHERE heartbeat < ?", (cutoff,))
            conn.commit()

    def record_decision(self, instance_id: str, subject: str, status: str, payload: Dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO decisions (decision_id, instance_id, subject, status, payload, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (str(uuid.uuid4()), instance_id, subject, status, json.dumps(payload, sort_keys=True), time.time()))
            conn.commit()

    def add_task(self, payload: Dict[str, Any]) -> str:
        task_id = str(uuid.uuid4())
        now = time.time()
        with self._connect() as conn:
            conn.execute("INSERT INTO tasks (task_id, payload, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)", (task_id, json.dumps(payload, sort_keys=True), "queued", now, now))
            conn.commit()
        return task_id

    def claim_task(self) -> Optional[Tuple[str, Dict[str, Any]]]:
        with self._connect() as conn:
            row = conn.execute("SELECT task_id, payload FROM tasks WHERE status = 'queued' ORDER BY created_at ASC LIMIT 1").fetchone()
            if not row:
                return None
            task_id = row["task_id"]
            conn.execute("UPDATE tasks SET status = 'running', updated_at = ? WHERE task_id = ?", (time.time(), task_id))
            conn.commit()
            return task_id, json.loads(row["payload"])

    def complete_task(self, task_id: str, status: str = "done") -> None:
        with self._connect() as conn:
            conn.execute("UPDATE tasks SET status = ?, updated_at = ? WHERE task_id = ?", (status, time.time(), task_id))
            conn.commit()
