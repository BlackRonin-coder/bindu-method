from bindu_runtime import WLEngine, BinduContext

def main() -> None:
    engine = WLEngine("/mnt/data/bindu_runtime_demo.db")
    ctx = BinduContext(
        subject="housing_delivery_system",
        request="WL optimise housing delivery under planning friction and capital misalignment",
        purpose="Increase real housing delivery while preserving dignity and reducing system friction.",
        constraints=["planning delay", "developer underbuild", "capital misallocation"],
        legal_constraints=["must remain legally deployable"],
        human_impact="Housing insecurity and delayed access affect lived reality directly.",
        assumptions=["not all actors will cooperate"],
        metadata={"command": "WL"},
    )
    task_id = engine.submit_context(ctx)
    print(f"Submitted task: {task_id}")
    result = engine.run_once()
    if result:
        print("\n=== SELF-GOVERNING WL / BINDU RESULT ===")
        print(f"Status: {result.status.value}")
        print(f"Selected action: {result.selected_action.name if result.selected_action else 'None'}")
        print(f"Alignment score: {result.alignment_score:.3f}")
        print(f"Survivability score: {result.survivability_score:.3f}")
        print(f"Wisdom score: {result.wisdom_score:.3f}")
        print(f"Outcome score: {result.outcome_score:.3f}")
        print(f"Utility score: {result.utility_score:.3f}")
        print(f"Drift severity: {result.drift_severity.value}")
        print("\nPatches applied:")
        if result.selected_action:
            for patch in result.selected_action.patches_applied:
                print(f"- {patch}")
        print("\nReasons:")
        for reason in result.reasons:
            print(f"- {reason}")

if __name__ == "__main__":
    main()
